Cpp2lua
=======

Register c++ class member variables and functions to lua.